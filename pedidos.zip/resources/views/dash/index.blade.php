@extends('adminlte::page')

@section('title', 'Melo Express')

@section('content_header')
    <h1>Melo Express</h1>
@stop

@section('content')
    <p>Welcome to this beautiful admin panel.</p>
@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop


