


<?php $__env->startSection('title', 'Melo Express'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 style="text-align:center">Melo Express</h1>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<h1>Listado de Pedidos</h1>
<div><a href="/pedidos/create" class="btn btn-primary"> Agregar Pedido</a></div>
<br>
<table id="tpedido" class="table table-bordered table-striped shadow-lg mt-4">
<thead>
    <tr>
        <th scope="col">ID</th>
        <th scope="col">Vendedor</th>
        <th scope="col">Direccion</th>
        <th scope="col">Telefono</th>
        <th scope="col">Tipo</th>
        <th scope="col">Estado</th>
        <th scope="col">Acciones</th>
    </tr>
</thead>
<tbody>
    <?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($pedido->id); ?></td>
    <td><?php echo e($pedido->vendedor); ?></td>
    <td><?php echo e($pedido->direccion); ?></td>
    <td><?php echo e($pedido->telefono); ?></td>
    <td><?php echo e($pedido->tipo); ?></td>
    <td><?php echo e($pedido->estado); ?></td>
    <td>
        <a class="btn btn-info">Editar</a>
        <button class="btn btn-danger">Borrar</button>
    </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>

<script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js" defer></script>



<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js" defer></script>
<script src="https://cdn.datatables.net/plug-ins/1.10.15/i18n/Spanish.json"></script>


<script>
       


    $(function(){
  $('#tpedido').DataTable();
})
        $(document).ready(function () {
    $('#tpedido').DataTable();
});
    </script>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.rtl.min.css" integrity="sha384-7mQhpDl5nRA5nY9lr8F1st2NbIly/8WqhjTp+0oFxEA/QUuvlbF6M1KXezGBh3Nb" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
    
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css" />
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Pedidos\resources\views/pedido/index.blade.php ENDPATH**/ ?>